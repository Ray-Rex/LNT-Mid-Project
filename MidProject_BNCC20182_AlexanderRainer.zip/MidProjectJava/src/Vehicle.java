import java.util.Scanner;
// import java.util.regex;

public class Vehicle {

    Scanner scan = new Scanner(System.in);

    private String vehicleType; // motor / mobil
    private String brand;
    private String name;
    private String license;
    private int topSpeed;
    private int gasCap;
    private int wheel;
    private String type;
    private int extra; // helm / entertainment system

    //setter
    public void setVehicleType() {
        String tmp;
        do {
            System.out.print("Input type [Car | Motorcycle]: ");
            tmp = scan.nextLine();
        } while (!tmp.equals("Motorcycle") && !tmp.equals("Car"));
        this.vehicleType = tmp;
    }
    
	public void setBrand() {
        String tmp;
        do {
            System.out.print("Input brand [>= 5]: ");
            tmp = scan.nextLine();
        } while (tmp.length() < 5);
        this.brand = tmp;
    }

    public void setName() {
        String tmp;
        do {
            System.out.print("Input name [>= 5]: ");
            tmp = scan.nextLine();
        } while (tmp.length() < 5);
        this.name = tmp;
    }
    
    public void setLicense() {
        String tmp;
        String template = "[A-Z]+ [0-9]{1,4}+ [A-Z]{1,3}+";
        do {
            System.out.print("Input license: ");
            tmp = scan.nextLine();
        } while (!tmp.matches(template));
        this.license = tmp;
    }

    public void setTopSpeed() {
        int tmp;
        do {
            System.out.print("Input top speed [100 <= topSpeed <= 250]: ");
            tmp = scan.nextInt(); scan.nextLine();
        } while (tmp < 100 || tmp > 250);
        this.topSpeed = tmp;
    }

    public void setGasCap() {
        int tmp;
        do {
            System.out.print("Input gas capacity [30 <= gasCap <= 60]: ");
            tmp = scan.nextInt(); scan.nextLine();
        } while (tmp < 30 || tmp > 60);
        this.gasCap = tmp;
    }

    public void setWheel() {
        int tmp;
        
        // if car
        if(vehicleType.equals("Car")) do {
            System.out.print("Input wheel [4 <= wheel <= 6]: ");
            tmp = scan.nextInt(); scan.nextLine();
        } while (tmp < 4 || tmp > 6);
        
        // else motorcycle
        else do {
            System.out.print("Input wheel [2 <= wheel <= 3]: ");
            tmp = scan.nextInt(); scan.nextLine();
        } while (tmp < 2 || tmp > 3);
        this.wheel = tmp;
    }

    public void setType() {
        String tmp;
        
        // if car
        if(vehicleType.equals("Car")) do {
            System.out.print("Input type [SUV | Supercar | Minivan]: ");
            tmp = scan.nextLine();
        } while (!tmp.equals("SUV") && !tmp.equals("Supercar") && !tmp.equals("Minivan"));
        
        // else motorcycle
        else do {
            System.out.print("Input type [Automatic | Manual]: ");
            tmp = scan.nextLine();
        } while (!tmp.equals("Automatic") && !tmp.equals("Manual"));
        this.type = tmp;
    }

    public void setExtra() {
        int tmp;
        do {
            // if car
            if (vehicleType.equals("Car")) System.out.print("Input entertainment system amount [>= 1]: ");
            // if motorcycle
            else System.out.print("Input helm amount [>= 1]: ");
            tmp = scan.nextInt(); scan.nextLine();
        } while (tmp < 1);
        this.extra = tmp;
    }
    
    //getter
	public String getVehicleType() {
        return this.vehicleType;
    }
	public String getBrand() {
        return this.brand;
    }
    public String getName() {
        return this.name;
    }
    public String getLicense() {
        return this.license;
    }
    public int getTopSpeed() {
        return this.topSpeed;
    }
    public int getGasCap() {
        return this.gasCap;
    }
    public int getWheel() {
        return this.wheel;
    }
    public String getType() {
        return this.type;
    }
    public int getExtra() {
        return this.extra;
    }
}