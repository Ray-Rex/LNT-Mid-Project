import java.util.Scanner;
import java.util.ArrayList;
// package MidProjectJava;

public class Main {
	
	static Scanner scan = new Scanner(System.in);
	static int n = 0;
	static ArrayList<Vehicle>list = new ArrayList<>();

	public static void main(String[] args) {
		int menu = 0;
		do{
			// print menu
			System.out.println("MAIN MENU");
			System.out.println("=========");
			System.out.println("1. Input");
			System.out.println("2. View");
			System.out.println("3. Exit");

			// menu options
			do {
				System.out.print(">> ");
				menu = scan.nextInt(); scan.nextLine();
			} while(menu != 1 && menu != 2 && menu != 3);

			if(menu == 1) input();
			else if(menu == 2) view();

		} while (menu != 3);
	}

	public static void input() {
		Vehicle tmp = new Vehicle();
		tmp.setVehicleType();
		tmp.setBrand();
		tmp.setName();
		tmp.setLicense();
		tmp.setTopSpeed();
		tmp.setGasCap();
		tmp.setWheel();
		tmp.setType();
		tmp.setExtra();

		list.add(tmp);
		n++;
	}

	public static void view() {
		System.out.println("|-----|---------------|---------------|");
		System.out.println("|No   |Type           |Name           |");
		System.out.println("|-----|---------------|---------------|");
		for (int i = 0; i < n; i++) {
			System.out.printf("|%-5s|%-15s|%-15s|\n", Integer.toString(i+1), list.get(i).getType(), list.get(i).getName());
		}
		System.out.println("|-----|---------------|---------------|");
		
		int option;
		do {
			System.out.println("Pick a vehicle number to test drive [Enter '0' to exit]: ");
			option = scan.nextInt(); scan.nextLine();
		} while(option < 0 || option > n);
		if (option == 0) return;
		printStats(option - 1);
	}

	public static void printStats(int idx) {
		Vehicle tmp = list.get(idx);

        System.out.println("Brand: " + tmp.getBrand());
        System.out.println("Name: " + tmp.getName()); 
        System.out.println("License Plate: " + tmp.getLicense());
        System.out.println("Type: " + tmp.getType());
		System.out.println("Gas Capacity: " + tmp.getGasCap());
		System.out.println("Top Speed: " + tmp.getTopSpeed());
        System.out.println("Wheel: " + tmp.getWheel());
        
		if (tmp.getVehicleType().equals("Car")) {
			System.out.println("Entertainment System: " + tmp.getExtra());
			System.out.println("Turning on entertainment system...");
			if(tmp.getType().equals("Supercar")) System.out.println("Boosting!");
		}
		else {
			System.out.println("Helm amount: " + tmp.getExtra());
			System.out.println(tmp.getName() + " is standing!");
		}
		System.out.println("Press enter to continue...");
		scan.nextLine();
    }
}